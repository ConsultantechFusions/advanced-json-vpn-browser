import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Globe, Wifi, WifiOff, Shield, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface VPNControllerProps {
  onConnect: (connected: boolean, country?: string) => void;
  onCountryChange: (country: string) => void;
  isConnected: boolean;
}

export default function VPNController({
  onConnect,
  onCountryChange,
  isConnected,
}: VPNControllerProps) {
  const [selectedCountry, setSelectedCountry] = useState("1");
  const [connecting, setConnecting] = useState(false);
  const [sessionId] = useState(() => `session-${Date.now()}`);

  // Get VPN countries from backend
  const { data: countries = [], isLoading } = trpc.vpn.getCountries.useQuery();

  // Connect to VPN mutation
  const connectMutation = trpc.vpn.connect.useMutation();
  const disconnectMutation = trpc.vpn.disconnect.useMutation();

  const handleCountryChange = (value: string) => {
    setSelectedCountry(value);
    const country = countries.find((c) => c.id.toString() === value);
    if (country) {
      onCountryChange(country.name);
    }
  };

  const handleToggleConnection = async () => {
    setConnecting(true);
    try {
      if (isConnected) {
        // Disconnect
        await disconnectMutation.mutateAsync({ sessionId });
        onConnect(false);
      } else {
        // Connect
        const result = await connectMutation.mutateAsync({
          countryId: parseInt(selectedCountry),
          sessionId,
        });
        if (result.success) {
          onConnect(true, result.country);
        }
      }
    } catch (error) {
      console.error("VPN connection error:", error);
    } finally {
      setConnecting(false);
    }
  };

  const selectedCountryData = countries.find(
    (c) => c.id.toString() === selectedCountry
  );

  return (
    <div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-gradient-to-r from-slate-700/40 to-slate-600/30 rounded-lg border border-slate-600 shadow-lg hover:shadow-xl transition-shadow duration-300">
      {/* VPN Status Indicator */}
      <div className="flex items-center gap-2 px-3 py-2 bg-slate-800/50 rounded-lg border border-slate-600">
        <Shield className="w-5 h-5 text-blue-400 animate-pulse" />
        <span className="text-sm font-bold text-blue-300">خدمة VPN:</span>
      </div>

      {/* Country Selector */}
      <Select value={selectedCountry} onValueChange={handleCountryChange} disabled={isLoading}>
        <SelectTrigger className="w-full sm:w-64 bg-slate-800 border-slate-600 text-white">
          <SelectValue placeholder={isLoading ? "جاري التحميل..." : "اختر الدولة"} />
        </SelectTrigger>
        <SelectContent className="bg-slate-800 border-slate-600">
          {countries.map((country) => (
            <SelectItem
              key={country.id}
              value={country.id.toString()}
              className="text-white hover:bg-slate-700 cursor-pointer"
            >
              {country.flag} {country.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Connection Status */}
      <div
        className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all duration-300 ${
          isConnected
            ? "bg-green-900/30 border-green-600 shadow-lg shadow-green-500/20"
            : "bg-red-900/30 border-red-600"
        }`}
      >
        <div
          className={`w-3 h-3 rounded-full ${
            isConnected
              ? "bg-green-500 animate-pulse shadow-lg shadow-green-500"
              : "bg-red-500"
          }`}
        />
        <span
          className={`text-sm font-bold ${
            isConnected ? "text-green-300" : "text-red-300"
          }`}
        >
          {isConnected ? "✓ متصل" : "✗ غير متصل"}
        </span>
      </div>

      {/* Connect/Disconnect Button */}
      <Button
        onClick={handleToggleConnection}
        disabled={connecting || isLoading}
        className={`ml-auto transition-all duration-300 font-bold shadow-lg hover:shadow-xl ${
          isConnected
            ? "bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-green-500/50"
            : "bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white shadow-red-500/50"
        }`}
      >
        <div className="flex items-center gap-2">
          {connecting ? (
            <>
              <Zap className="w-4 h-4 animate-spin" />
              <span>جاري الاتصال...</span>
            </>
          ) : isConnected ? (
            <>
              <Wifi className="w-4 h-4 animate-pulse" />
              <span>قطع الاتصال</span>
            </>
          ) : (
            <>
              <WifiOff className="w-4 h-4" />
              <span>الاتصال</span>
            </>
          )}
        </div>
      </Button>
    </div>
  );
}

