import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import {
  Copy,
  Download,
  Trash2,
  FileJson,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

export default function JSONConverter() {
  const [inputText, setInputText] = useState("");
  const [outputJSON, setOutputJSON] = useState("");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const convertToJSON = () => {
    try {
      setError("");
      // محاولة تحليل النص كـ JSON
      if (inputText.trim().startsWith("{") || inputText.trim().startsWith("[")) {
        const parsed = JSON.parse(inputText);
        setOutputJSON(JSON.stringify(parsed, null, 2));
      } else {
        // تحويل النص العادي إلى JSON
        const jsonOutput = {
          text: inputText,
          timestamp: new Date().toISOString(),
          length: inputText.length,
        };
        setOutputJSON(JSON.stringify(jsonOutput, null, 2));
      }
    } catch (err) {
      setError("خطأ في تحليل JSON: " + (err as Error).message);
      setOutputJSON("");
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(outputJSON);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    element.setAttribute(
      "href",
      "data:text/json;charset=utf-8," + encodeURIComponent(outputJSON)
    );
    element.setAttribute("download", "output.json");
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleClear = () => {
    setInputText("");
    setOutputJSON("");
    setError("");
  };

  return (
    <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 p-4 h-full flex flex-col shadow-lg hover:shadow-xl hover:shadow-blue-500/20 transition-all duration-300">
      <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-700">
        <FileJson className="w-5 h-5 text-blue-400 animate-pulse" />
        <h3 className="text-lg font-bold text-white">محول JSON</h3>
      </div>

      {/* Input Area */}
      <div className="mb-4 flex-1 flex flex-col">
        <label className="text-sm font-bold text-blue-300 mb-2">
          أدخل النص أو JSON:
        </label>
        <Textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="أدخل النص أو JSON هنا..."
          className="flex-1 bg-slate-900/50 border-slate-600 hover:border-slate-500 text-white text-sm placeholder-slate-500 resize-none focus:bg-slate-900 focus:border-blue-500 transition-all"
        />
      </div>

      {/* Buttons */}
      <div className="flex gap-2 mb-4">
        <Button
          onClick={convertToJSON}
          className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold shadow-lg hover:shadow-xl shadow-blue-500/50"
        >
          تحويل إلى JSON
        </Button>
        <Button
          onClick={handleClear}
          variant="outline"
          className="border-slate-600 text-slate-300 hover:bg-slate-700"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-4 p-3 bg-red-900/30 border border-red-700 rounded-lg flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-red-300">{error}</p>
        </div>
      )}

      {/* Output Area */}
      {outputJSON && (
        <div className="mb-4 flex-1 flex flex-col">
          <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-700">
            <CheckCircle className="w-4 h-4 text-green-400 animate-pulse" />
            <label className="text-sm font-bold text-green-300">
              النتيجة:
            </label>
          </div>
          <Textarea
            value={outputJSON}
            readOnly
            className="flex-1 bg-slate-900/50 border-slate-600 text-white text-xs placeholder-slate-500 resize-none font-mono hover:border-slate-500 transition-colors"
          />
        </div>
      )}

      {/* Action Buttons */}
      {outputJSON && (
        <div className="flex gap-2">
          <Button
            onClick={handleCopy}
            className="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold shadow-lg shadow-green-500/50"
          >
            <Copy className="w-4 h-4 mr-2" />
            {copied ? "تم النسخ!" : "نسخ"}
          </Button>
          <Button
            onClick={handleDownload}
            variant="outline"
            className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <Download className="w-4 h-4 mr-2" />
            تحميل
          </Button>
        </div>
      )}

      {/* Info Box */}
      <div className="mt-4 p-3 bg-gradient-to-r from-blue-900/30 to-slate-700/30 border border-blue-600/30 rounded-lg shadow-lg shadow-blue-500/10">
        <p className="text-xs text-slate-300 leading-relaxed">
          💡 <strong className="text-blue-300">نصيحة:</strong> يمكنك إدخال نص عادي أو JSON وتحويله بسهولة
        </p>
      </div>
    </Card>
  );
}

