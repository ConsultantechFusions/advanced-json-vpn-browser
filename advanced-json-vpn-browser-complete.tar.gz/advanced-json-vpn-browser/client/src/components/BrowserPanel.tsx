import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Globe,
  X,
} from "lucide-react";

interface BrowserPanelProps {
  vpnCountry: string;
  vpnConnected: boolean;
}

interface BrowserWindow {
  id: string;
  url: string;
  title: string;
  loading: boolean;
}

export default function BrowserPanel({
  vpnCountry,
  vpnConnected,
}: BrowserPanelProps) {
  const [browsers, setBrowsers] = useState<BrowserWindow[]>([
    {
      id: "browser-1",
      url: "https://www.google.com",
      title: "Google",
      loading: false,
    },
    {
      id: "browser-2",
      url: "https://www.wikipedia.org",
      title: "Wikipedia",
      loading: false,
    },
  ] as BrowserWindow[]);

  const handleUrlChange = (id: string, newUrl: string) => {
    // التحقق من صحة الـ URL
    let validUrl = newUrl;
    if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
      validUrl = 'https://' + newUrl;
    }

    setBrowsers((prev) =>
      prev.map((b) =>
        b.id === id
          ? { ...b, url: validUrl, loading: true, title: "جاري التحميل..." }
          : b
      )
    );

    // محاكاة تحميل الصفحة
    setTimeout(() => {
      try {
        const hostname = new URL(validUrl).hostname || validUrl;
        setBrowsers((prev) =>
          prev.map((b) =>
            b.id === id
              ? {
                  ...b,
                  loading: false,
                  title: hostname,
                }
              : b
          )
        );
      } catch (error) {
        setBrowsers((prev) =>
          prev.map((b) =>
            b.id === id
              ? {
                  ...b,
                  loading: false,
                  title: 'خطأ في الـ URL',
                }
              : b
          )
        );
      }
    }, 1000);
  };

  const handleRefresh = (id: string) => {
    setBrowsers((prev) =>
      prev.map((b) =>
        b.id === id ? { ...b, loading: true } : b
      )
    );

    setTimeout(() => {
      setBrowsers((prev) =>
        prev.map((b) =>
          b.id === id ? { ...b, loading: false } : b
        )
      );
    }, 1000);
  };

  const handleRemoveBrowser = (id: string) => {
    if (browsers.length > 1) {
      setBrowsers((prev) => prev.filter((b) => b.id !== id));
    }
  };

  const handleAddBrowser = () => {
    const newId = `browser-${Date.now()}`;
    setBrowsers((prev) => {
      const newBrowser = {
        id: newId,
        url: "https://www.google.com",
        title: "Google",
        loading: false,
      };
      return [...prev, newBrowser];
    });
  };

  return (
    <div className="space-y-4 h-full flex flex-col">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Globe className="w-5 h-5 text-blue-400 animate-pulse" />
          متصفح الويب المدمج
        </h2>
        <Button
          onClick={handleAddBrowser}
          size="sm"
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          + نافذة جديدة
        </Button>
      </div>

      {/* VPN Status Banner */}
      {vpnConnected && (
        <div className="p-3 bg-green-900/30 border border-green-700 rounded-lg flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-sm text-green-300">
            متصل عبر VPN من {vpnCountry.toUpperCase()}
          </span>
        </div>
      )}

      {/* Browser Windows Grid */}
      <div className={`grid gap-4 flex-1 overflow-auto ${browsers.length === 1 ? "grid-cols-1" : "grid-cols-1 lg:grid-cols-2"}`}>
        {browsers.map((browser) => (
            <Card
            key={browser.id}
            className="bg-slate-800 border-slate-700 overflow-hidden flex flex-col h-96 hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300"
          >
            {/* Browser Toolbar */}
            <div className="bg-gradient-to-r from-slate-700/50 to-slate-600/30 border-b border-slate-600 p-3 space-y-2">
              {/* Navigation Bar */}
              <div className="flex items-center gap-2">
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 text-slate-300 hover:text-white hover:bg-slate-600"
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 text-slate-300 hover:text-white hover:bg-slate-600"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => handleRefresh(browser.id)}
                  disabled={browser.loading}
                  className="h-8 w-8 text-slate-300 hover:text-white hover:bg-slate-600"
                >
                  <RotateCcw
                    className={`w-4 h-4 ${browser.loading ? "animate-spin" : ""}`}
                  />
                </Button>
              </div>

              {/* Address Bar */}
              <div className="flex items-center gap-2">
                <Input
                  type="text"
                  value={browser.url}
                  onChange={(e) => {
                    const newUrl = e.target.value;
                    setBrowsers((prev) =>
                      prev.map((b) =>
                        b.id === browser.id ? { ...b, url: newUrl } : b
                      )
                    );
                  }}
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleUrlChange(browser.id, browser.url);
                    }
                  }}
                  placeholder="أدخل عنوان الموقع..."
                  className="flex-1 h-8 bg-slate-700 border-0 text-white text-sm placeholder-slate-400 focus:bg-slate-600 transition-colors"
                />
                {browsers.length > 1 && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => handleRemoveBrowser(browser.id)}
                    className="h-8 w-8 text-slate-300 hover:text-red-400 hover:bg-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>

              {/* Page Title */}
              <div className="text-xs text-slate-400 truncate">
                {browser.loading ? "جاري التحميل..." : browser.title}
              </div>
            </div>

            {/* Browser Content Area */}
            <div className="flex-1 bg-slate-900 overflow-hidden relative border-t border-slate-700">
              <iframe
                key={browser.url}
                src={browser.url}
                title={browser.title}
                className="w-full h-full border-none"
                sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
              />

              {/* Loading Overlay */}
              {browser.loading && (
                <div className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center">
                  <div className="flex flex-col items-center gap-3">
                    <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-400" />
                    <span className="text-sm text-blue-300">جاري التحميل...</span>
                  </div>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Info Box */}
      <div className="p-4 bg-gradient-to-r from-blue-900/30 to-slate-700/30 border border-blue-600/30 rounded-lg shadow-lg shadow-blue-500/10">
        <p className="text-sm text-slate-300">
          💡 <strong>نصيحة:</strong> يمكنك فتح عدة نوافذ متصفح بشكل مستقل، وكل نافذة لها شريط عناوين وأدوات خاصة بها.
          {vpnConnected && (
            <span className="block mt-2 text-green-300">
              ✓ جميع الاتصالات تمر عبر VPN من {vpnCountry.toUpperCase()}
            </span>
          )}
        </p>
      </div>
    </div>
  );
}

