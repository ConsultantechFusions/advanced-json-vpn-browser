import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { APP_LOGO, APP_TITLE } from "@/const";
import { useState } from "react";
import VPNController from "@/components/VPNController";
import BrowserPanel from "@/components/BrowserPanel";
import JSONConverter from "@/components/JSONConverter";

export default function Home() {
  const { user, loading, error, isAuthenticated, logout } = useAuth();
  const [vpnConnected, setVpnConnected] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState("us");

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-8 w-8" />}
            <h1 className="text-2xl font-bold text-white">{APP_TITLE}</h1>
          </div>
          
          {isAuthenticated && (
            <div className="flex items-center gap-4">
              <span className="text-sm text-slate-300">{user?.name}</span>
              <Button 
                variant="outline" 
                size="sm"
                onClick={logout}
                className="text-slate-300 border-slate-600 hover:bg-slate-700"
              >
                تسجيل الخروج
              </Button>
            </div>
          )}
        </div>
      </header>

      {/* VPN Controller */}
      <div className="border-b border-slate-700 bg-slate-800/30 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <VPNController 
            onConnect={setVpnConnected}
            onCountryChange={setSelectedCountry}
            isConnected={vpnConnected}
          />
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* JSON Converter - Left Side */}
          <div className="lg:col-span-1">
            <JSONConverter />
          </div>

          {/* Browser Panels - Right Side */}
          <div className="lg:col-span-2">
            <BrowserPanel vpnCountry={selectedCountry} vpnConnected={vpnConnected} />
          </div>
        </div>
      </main>
    </div>
  );
}

