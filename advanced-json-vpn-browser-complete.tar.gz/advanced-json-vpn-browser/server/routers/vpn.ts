import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

// VPN Countries Configuration
const VPN_COUNTRIES = {
  1: { name: "USA", ip: "10.0.0.2", flag: "🇺🇸", code: "us" },
  2: { name: "UK", ip: "10.0.0.3", flag: "🇬🇧", code: "uk" },
  3: { name: "France", ip: "10.0.0.4", flag: "🇫🇷", code: "fr" },
  4: { name: "Germany", ip: "10.0.0.5", flag: "🇩🇪", code: "de" },
  5: { name: "Japan", ip: "10.0.0.6", flag: "🇯🇵", code: "jp" },
  6: { name: "Australia", ip: "10.0.0.7", flag: "🇦🇺", code: "au" },
  7: { name: "Canada", ip: "10.0.0.8", flag: "🇨🇦", code: "ca" },
  8: { name: "Singapore", ip: "10.0.0.9", flag: "🇸🇬", code: "sg" },
  9: { name: "Netherlands", ip: "10.0.0.10", flag: "🇳🇱", code: "nl" },
  10: { name: "Russia", ip: "10.0.0.11", flag: "🇷🇺", code: "ru" },
} as const;

// Store active VPN connections in memory (in production, use database)
const activeConnections: Map<string, { country: string; connectedAt: Date }> = new Map();

export const vpnRouter = router({
  // Get list of available VPN countries
  getCountries: publicProcedure.query(() => {
    return Object.entries(VPN_COUNTRIES).map(([id, data]) => ({
      id: parseInt(id),
      ...data,
    }));
  }),

  // Connect to VPN
  connect: publicProcedure
    .input(
      z.object({
        countryId: z.number().min(1).max(10),
        sessionId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const country = VPN_COUNTRIES[input.countryId as keyof typeof VPN_COUNTRIES];
        if (!country) {
          return {
            success: false,
            error: "Invalid country ID",
          };
        }

        // Simulate VPN connection (in production, this would actually connect via WireGuard)
        activeConnections.set(input.sessionId, {
          country: country.name,
          connectedAt: new Date(),
        });

        return {
          success: true,
          message: `Connected to VPN in ${country.name}`,
          country: country.name,
          ip: country.ip,
          flag: country.flag,
          connectedAt: new Date().toISOString(),
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Connection failed",
        };
      }
    }),

  // Disconnect from VPN
  disconnect: publicProcedure
    .input(
      z.object({
        sessionId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const connection = activeConnections.get(input.sessionId);
        if (!connection) {
          return {
            success: false,
            error: "No active connection",
          };
        }

        activeConnections.delete(input.sessionId);

        return {
          success: true,
          message: "Disconnected from VPN",
          disconnectedAt: new Date().toISOString(),
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : "Disconnection failed",
        };
      }
    }),

  // Get current VPN status
  getStatus: publicProcedure
    .input(
      z.object({
        sessionId: z.string(),
      })
    )
    .query(({ input }) => {
      const connection = activeConnections.get(input.sessionId);
      if (!connection) {
        return {
          connected: false,
          country: null,
          connectedAt: null,
        };
      }

      return {
        connected: true,
        country: connection.country,
        connectedAt: connection.connectedAt.toISOString(),
        duration: Math.floor((Date.now() - connection.connectedAt.getTime()) / 1000),
      };
    }),

  // Get VPN configuration for client
  getClientConfig: publicProcedure
    .input(
      z.object({
        countryId: z.number().min(1).max(10),
      })
    )
    .query(({ input }) => {
      const country = VPN_COUNTRIES[input.countryId as keyof typeof VPN_COUNTRIES];
      if (!country) {
        return null;
      }

      // In production, this would read actual WireGuard configuration files
      return {
        country: country.name,
        ip: country.ip,
        flag: country.flag,
        config: `# WireGuard Configuration for ${country.name}\n# This is a placeholder configuration\n# In production, actual WireGuard configs would be served here`,
      };
    }),

  // Test VPN connection speed
  testSpeed: publicProcedure
    .input(
      z.object({
        sessionId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const connection = activeConnections.get(input.sessionId);
      if (!connection) {
        return {
          success: false,
          error: "No active VPN connection",
        };
      }

      // Simulate speed test (in production, this would perform actual speed tests)
      const downloadSpeed = Math.floor(Math.random() * 100) + 50; // 50-150 Mbps
      const uploadSpeed = Math.floor(Math.random() * 50) + 20; // 20-70 Mbps
      const ping = Math.floor(Math.random() * 50) + 10; // 10-60 ms

      return {
        success: true,
        downloadSpeed: `${downloadSpeed} Mbps`,
        uploadSpeed: `${uploadSpeed} Mbps`,
        ping: `${ping} ms`,
        country: connection.country,
      };
    }),
});

